
from django.urls import path
from . import views


urlpatterns = [
    path("",                                views.allemployees, name="allemployees"),
    path("allemployees/",                   views.allemployees, name="allemployees"),
    path("singleemployee/<int:empid>/",     views.singleemployee, name="singleemployee"),
    path("schedulingemployee/",             views.schedulingemployee, name="schedulingemployee"),
    path("addemployee/",                    views.addemployee, name="addemployee"),
    path("attendance/",                     views.attendance, name="attendance"),
    path("deleteemployee/<int:empid>/",     views.deleteemployee, name="deleteemployee"),
    path("updateemployee/<int:empid>/",     views.updateemployee, name="updateemployee"),
    path("doupdateemployee/<int:empid>/",   views.doupdateemployee, name="doupdateemployee"),
    path('all_events/',     views.all_events, name='all_events'), 
    path('add_event/',      views.add_event, name='add_event'), 
    path('update/',         views.update, name='update'),
    path('remove/',         views.remove, name='remove'),
]